package com.example.intranetsampleapp;

import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.Arrays;
import java.util.Collection;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;

/**
 * Created by Shankar on 05/02/2018.
 */

public class OkHttpHelper {

    public static final MediaType MEDIA_TYPE_JSON
            = MediaType.parse("application/json; charset=utf-8");


    /**
     * Returns OkHttpClient with standard configuration
     *
     * @return
     */
   /* public OkHttpClient createOkHttpClient() {
        OkHttpClient client;
        X509TrustManager trustManager;
        SSLSocketFactory sslSocketFactory;
        try {
            trustManager = trustManagerForCertificates(trustedCertificatesInputStream());
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[] { trustManager }, null);
            sslSocketFactory = sslContext.getSocketFactory();
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        }

        client = new OkHttpClient.Builder()
                .sslSocketFactory(sslSocketFactory, trustManager)
                .build();
        return client;
    }
*/
    /**
     * For bypassing SSL certificate validation
     *
     * @param builder
     * @return builder
     */
    public static OkHttpClient.Builder configureToIgnoreCertificate(OkHttpClient.Builder builder) {
        try {
            /*Create a trust manager that does not validate certificate chains*/
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType)
                                throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType)
                                throws CertificateException {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            /*Install the all-trusting trust manager*/
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            /*Create an ssl socket factory with our all-trusting manager*/
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
            builder.sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0]);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });
        } catch (Exception e) {
            Log.v("vinod", "Exception configureToIgnoreCertificate()");
        }
        return builder;
    }



    /**
     * Returns an input stream containing one or more certificate PEM files. This implementation just
     * embeds the PEM files in Java strings; most applications will instead read this from a resource
     * file that gets bundled with the application.
     */
   /* private InputStream trustedCertificatesInputStream() {
        String
        certificate ="-----BEGIN CERTIFICATE REQUEST-----\n" +
                "MIIEhzCCAm8CAQAwQjELMAkGA1UEBhMCWFgxFTATBgNVBAcMDERlZmF1bHQgQ2l0\n" +
                "eTEcMBoGA1UECgwTRGVmYXVsdCBDb21wYW55IEx0ZDCCAiIwDQYJKoZIhvcNAQEB\n" +
                "BQADggIPADCCAgoCggIBAMQ33rfN1xnnl4S6vk7AeixkfCaNUzbQuM3hwfL6poky\n" +
                "Zzw9tftmU5SrnDEyNvNQoIZV/T/23gp+cAVeA1niSYcF74cmAZIL/2h73uqigAFq\n" +
                "GV0+QLdiJZqJAbi97DB5bxD5o3jkvuQDCRcQRzN7xhAImQQMrkKbtQ+87Tcc9ntL\n" +
                "KbkWKUGGzY0rIyXYyK/sBWSel/eCrku4Xr6WxPtQ7jCItaYkhEUg4wgMKROKNwwR\n" +
                "i5Qv8zzSquNpzP/fDTAsOlgD1BEL2xtTyQHT1fBA9OC9MKOEgUST5hZl80WxPj7H\n" +
                "xTGKZMDF9xMtiU9ldWHOfckRYT3vpIDswE1RQCbk/2qncFwF3tOwaKVbWY/Dx+BF\n" +
                "sMbF2CuhTKsiJ8ZfjANCBh8drSuqIAZ1ScpbmVbgHfzuR+HulssnWaaciMgasDX/\n" +
                "JoHNLFJ6U9oX5+1x2iIVNszoGrQxzQ4Bde9ybWPz9NiHuCGACL0nuFdiiXMrU8zO\n" +
                "4c0X0qcDHZKwn8w+zBM2PRzlBGVg/2D6iteiSetTxzFTAf86uwTGC81djHqN7Fr7\n" +
                "35q1UPdriuu66LWM2J/6QJKQYMtFVfu5jkcEfczCqCp7guObMJJPUsx2cpMuHwq7\n" +
                "XcoB04gLseFuFBJ1aIA3jhPcdobHb6by8v30McZzPmOUhIfYaX+sLTpUljWXGTU5\n" +
                "AgMBAAGgADANBgkqhkiG9w0BAQsFAAOCAgEAcp1X4fui3CXw5rh+LEU8GxsbOw5s\n" +
                "oTsYkAbdYPhqwsqK28aLFdfn/a0SWYqQTCk7Sh1rRbL++CJiS3B8XcIoiF8OxEgv\n" +
                "GrSHqtb5nucpjal6i+vXVKhMtzSDlUObXG4Nj8k2Zp5TekA2bO0PpZF4+Nm0cx39\n" +
                "z3dsYcAbstHRjBf/VXaTsMn/RcAOcObNwG2Bt2XZ7z2uUzPGOJbpgh1XQNPfh+zN\n" +
                "6tMKz1gM3tXC8VgaazffTvEHSFwEBiOXnNAGr6RINhYYWL2uZHgJiuM3HB/KmBKn\n" +
                "mFTJTRH7KISCELYu9IgDzxV2FjyXCTh7tRYATTaJpBubjXiOSBbgd34YM1z/N7vr\n" +
                "xOmXxZjhwKsN79uVy+gH4aOMS9DTVlt2hL1QU1EDGwKlDPmXa2lBHD91jmsGmIG8\n" +
                "ygWUd3lI3Z7pAlOfp0QFIxCz8diLR8f9mZjB2iKr4uTZrA7c0ByGCuUM87xfg1Ph\n" +
                "+PzhJDmOQkJuO1MX19o4mXd/Xifx79LErNOd/SBoPZi+WRVdDzk62IOsG9JcFhGD\n" +
                "GkhrjiK3nOYHYyrb02lsn/gkL42m8T8QQuVTN6nPpuqODC+x8eJviBVdFx7Wn9EH\n" +
                "xFMCqzFcs1aWVgUnyfhcAQpiZ2fF1JVSED2KYdleY5FgMoxaQXZps3L0tuh4XlT9\n" +
                "sagDWbgTvD20Y6o=\n" +
                "-----END CERTIFICATE REQUEST-----";
        *//*if(BuildConfig.FLAVOR.equalsIgnoreCase("sit")){
            certificate = NetworkConstants.SIT_CRT;
        }else if (BuildConfig.FLAVOR.equalsIgnoreCase("uat")){
            //certificate = NetworkConstants.UAT_CRT;
        }else if (BuildConfig.FLAVOR.equalsIgnoreCase("prod")){
           // certificate = NetworkConstants.PRD_CRT;
        }
*//*
        return new Buffer()
                .writeUtf8(certificate)
                .inputStream();
    }
*/


    /**
     * Returns a trust manager that trusts {@code certificates} and none other. HTTPS services whose
     * certificates have not been signed by these certificates will fail with a {@code
     * SSLHandshakeException}.
     *
     * <p>This can be used to replace the host platform's built-in trusted certificates with a custom
     * set. This is useful in development where certificate authority-trusted certificates aren't
     * available. Or in production, to avoid reliance on third-party certificate authorities.
     *
     * <p>See also {@link CertificatePinner}, which can limit trusted certificates while still using
     * the host platform's built-in trust store.
     *
     * <h3>Warning: Customizing Trusted Certificates is Dangerous!</h3>
     *
     * <p>Relying on your own trusted certificates limits your server team's ability to update their
     * TLS certificates. By installing a specific set of trusted certificates, you take on additional
     * operational complexity and limit your ability to migrate between certificate authorities. Do
     * not use custom trusted certificates in production without the blessing of your server's TLS
     * administrator.
     */
    private X509TrustManager trustManagerForCertificates(InputStream in)
            throws GeneralSecurityException {
        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
        Collection<? extends Certificate> certificates = certificateFactory.generateCertificates(in);
        if (certificates.isEmpty()) {
            throw new IllegalArgumentException("expected non-empty set of trusted certificates");
        }

        // Put the certificates a key store.
        char[] password = "password".toCharArray(); // Any password will work.
        KeyStore keyStore = newEmptyKeyStore(password);
        int index = 0;
        for (Certificate certificate : certificates) {
            String certificateAlias = Integer.toString(index++);
            keyStore.setCertificateEntry(certificateAlias, certificate);
        }

        // Use it to build an X509 trust manager.
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(
                KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(keyStore, password);
        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init(keyStore);
        TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
        if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
            throw new IllegalStateException("Unexpected default trust managers:"
                    + Arrays.toString(trustManagers));
        }
        return (X509TrustManager) trustManagers[0];
    }
    private KeyStore newEmptyKeyStore(char[] password) throws GeneralSecurityException {
        try {
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            InputStream in = null; // By convention, 'null' creates an empty key store.
            keyStore.load(in, password);
            return keyStore;
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }
}


