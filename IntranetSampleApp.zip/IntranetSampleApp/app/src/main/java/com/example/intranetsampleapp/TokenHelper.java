package com.example.intranetsampleapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;


import com.microsoft.aad.adal.AuthenticationCallback;
import com.microsoft.aad.adal.AuthenticationContext;
import com.microsoft.aad.adal.AuthenticationException;
import com.microsoft.aad.adal.AuthenticationResult;
import com.microsoft.aad.adal.AuthenticationSettings;
import com.microsoft.aad.adal.PromptBehavior;
import com.microsoft.aad.adal.Telemetry;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by karlpatrick on 07/09/2018.
 */

public class TokenHelper {

    private static TokenHelper instance;
    private AuthenticationContext mAuthContext;
    private final String mAuthority = NetworkConstants.AZURE_AD_LOGIN_URL + BuildConfig.TENAND_ID;
    private final String mResource = NetworkConstants.AZURE_AD_GRAPH_RESOURCE_URL;
    private final String mClientId = BuildConfig.AD_APP_ID;


    private TokenHelper(Context context){
        initADAL(context);
    }

    public static TokenHelper getInstance(Context context){
        if(instance == null){
            instance = new TokenHelper(context);
        }
        return instance;
    }

    private void initADAL(Context context){
        AuthenticationSettings.INSTANCE.setUseBroker(true);

        if(BuildConfig.DEBUG){
            SampleTelemetry telemetryDispatcher = new SampleTelemetry();
            Telemetry.getInstance().registerDispatcher(telemetryDispatcher, true);
        }

        mAuthContext = new AuthenticationContext(context, mAuthority, true);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data){
        mAuthContext.onActivityResult(requestCode, resultCode, data);
    }

    public void callAcquireToken(Activity activity, AuthenticationCallback authenticationCallback){
        Toast.makeText(activity, "callAcquireToken"+authenticationCallback, Toast.LENGTH_SHORT).show();
        Log.d("TAG"," at callAcquireToken"+authenticationCallback);
        mAuthContext.acquireToken(activity, mResource, mClientId, mAuthContext.getRedirectUriForBroker(), PromptBehavior.Auto, authenticationCallback);
    }

    public void callAcquireTokenSilentAsyc(String userId, AuthenticationCallback authenticationCallback){
        mAuthContext.acquireTokenSilentAsync(mResource, mClientId, userId, authenticationCallback);
    }

    public AuthenticationResult callAcquireTokenSilentSync(String userId) throws AuthenticationException, InterruptedException {
        return mAuthContext.acquireTokenSilentSync(mResource, mClientId, userId);
    }

    public  boolean isTokenExpired(long expiryDateMillis){
        Date expiryDate = new Date(expiryDateMillis);
        return expiryDate.before(Calendar.getInstance().getTime());
    }

}
