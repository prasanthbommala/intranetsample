package com.example.intranetsampleapp;

import com.microsoft.aad.adal.IDispatcher;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by Karl on 7/18/18.
 */

public class SampleTelemetry implements IDispatcher {

    @Override
    public void dispatchEvent(final Map<String, String> events) {
        final Iterator iterator = events.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map.Entry pair = (Map.Entry) iterator.next();
        }
    }
}
