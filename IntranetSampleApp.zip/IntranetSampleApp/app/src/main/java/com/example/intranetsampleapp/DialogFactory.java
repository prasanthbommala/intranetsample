package com.example.intranetsampleapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.StringRes;
import android.support.v7.app.AlertDialog;

public final class DialogFactory {

    public static void showDialog(Context ctx, String title, String message, boolean cancelable,
                                  DialogButton positiveButton, DialogButton negativeButton) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(ctx);
        builder.setCancelable(cancelable);
        builder.setMessage(message);
        builder.setPositiveButton(positiveButton.getTitle(), positiveButton.getOnClickListener());
        if (negativeButton != null) {
            builder.setNegativeButton(negativeButton.getTitle(), negativeButton.getOnClickListener());
        }
        if (title != null) builder.setTitle(title);
        builder.show();
    }

    public static class DialogButton {
        String title;
        DialogInterface.OnClickListener onClickListener;

        public DialogButton(String title, DialogInterface.OnClickListener clickListener) {
            this.title = title;
            this.onClickListener = clickListener;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public DialogInterface.OnClickListener getOnClickListener() {
            return onClickListener;
        }

        public void setOnClickListener(DialogInterface.OnClickListener onClickListener) {
            this.onClickListener = onClickListener;
        }
    }

    public static Dialog createSimpleOkErrorDialog(Context context, String title, String message) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(message)
                .setNeutralButton(R.string.dialog_action_ok, null);
        return alertDialog.create();
    }

    public static Dialog createSimpleOkErrorDialog(Context context,
                                                   @StringRes int titleResource,
                                                   @StringRes int messageResource) {

        return createSimpleOkErrorDialog(context,
                context.getString(titleResource),
                context.getString(messageResource));
    }

    public static Dialog createGenericErrorDialog(Context context, String message) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context)
                .setTitle(context.getString(R.string.dialog_error_title))
                .setMessage(message)
                .setNeutralButton(R.string.dialog_action_ok, null);
        return alertDialog.create();
    }

    public static Dialog createGenericErrorDialog(Context context, @StringRes int messageResource) {
        return createGenericErrorDialog(context, context.getString(messageResource));
    }

    public static ProgressDialog createProgressDialog(Context context, String message) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage(message);
        return progressDialog;
    }

    public static ProgressDialog createProgressDialog(Context context,
                                                      @StringRes int messageResource) {
        return createProgressDialog(context, context.getString(messageResource));
    }

}
