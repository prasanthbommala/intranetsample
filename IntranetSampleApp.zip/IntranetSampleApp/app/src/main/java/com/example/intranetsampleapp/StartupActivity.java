package com.example.intranetsampleapp;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.HttpAuthHandler;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import com.microsoft.identity.common.internal.net.HttpResponse;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.http.HttpHeaders;
import okhttp3.internal.http2.Header;

public class StartupActivity extends AppCompatActivity {
    WebView webView;
    String url = "https://rintr-sit.uat.dbs.com:8543/web/mydbs/welcome";
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        webView= (WebView) findViewById(R.id.intranetwebview);
        final WebSettings  settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDisplayZoomControls(false);
        settings.setDomStorageEnabled(true);
        settings.setAppCacheEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setBuiltInZoomControls(false);
        settings.setPluginState(WebSettings.PluginState.ON);

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Toast.makeText(StartupActivity.this,"should override",Toast.LENGTH_SHORT).show();
                return false;
            }

//            @Override
//            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
//                try {
//                    Request request = new Request.Builder().url(view.getUrl()).addHeader("tokenHeader","Sample123Android web").build();
//                    OkHttpClient.Builder builder = new OkHttpClient.Builder();
//                    OkHttpClient okHttpClient = OkHttpHelper.configureToIgnoreCertificate(builder).build();
//                    Response response = okHttpClient.newCall(request).execute();
//                    //ResponseBody body = response.body();
//                    // Toast.makeText(getApplicationContext(),"vinod RES"+body.string(),Toast.LENGTH_SHORT).show();
//                    return new WebResourceResponse("","",response.body().byteStream());
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//                return null;
//            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error){
                handler.proceed();
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                hideProgressDialogWithTitle();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                hideProgressDialogWithTitle();
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                hideProgressDialogWithTitle();
            }
        });
        loadwebView();
        }

    public void loadwebView(){
        if(NetworkUtil.isNetworkConnected(this)){
            if(NetworkUtil.isVPNenabled(this)) {
                progressDialog = new ProgressDialog(this);
                showProgressDialogWithTitle();
                webView.loadUrl(url);
           } else {
                DialogFactory.showDialog(this, "VPN Error", "Please check your VPN Connection and try again", false,  new DialogFactory.DialogButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        System.exit(0);
                    }
                }), new DialogFactory.DialogButton("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        loadwebView();
                        return;
                    }
                }));
            }
        } else {
            DialogFactory.showDialog(this, "Network Error", getString(R.string.error_no_network), false,  new DialogFactory.DialogButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    System.exit(0);
                }
            }), new DialogFactory.DialogButton("Retry", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    loadwebView();
                    return;
                }
            }));
        }

    }

    private void showProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait ...");
        progressDialog.show();
    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
