package com.example.intranetsampleapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class LauncherActivity extends AppCompatActivity implements LauncherView {

    private ProgressBar progressBar;
    private LauncherPresenter presenter;
    private Context context;
    SharedPreferences sharedpreferences;
    public static final String mypreference = "mypref";
    public static final String azureId = "azureId";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        progressBar = findViewById(R.id.progress);
        sharedpreferences = getSharedPreferences(mypreference,
                Context.MODE_PRIVATE);
        presenter = new LauncherPresenter(this, new LauncherInteractor());
        Toast.makeText(getApplicationContext(), "at launcher activity ", Toast.LENGTH_SHORT).show();
        Log.d("TAG","at launcher activity");
        presenter.initializeAccessToken(this,sharedpreferences);

    }

    @Override
    public void openContainerActivity() {
        startActivity(new Intent(getBaseContext(), StartupActivity.class));
        finish();
    }

    @Override
    public void showAuthenticationError() {
        DialogFactory.showDialog(this, "Error", getString(R.string.error_authentication), false,  new DialogFactory.DialogButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        }), null);
    }

    @Override
    public void showConnectionError() {
            // User don't have user details -> Block them from entering the app.
            DialogFactory.showDialog(this, "Error", getString(R.string.error_unable_connect_server), false,  new DialogFactory.DialogButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    System.exit(0);
                }
            }), null);
    }

    @Override
    public void showNetworkError() {
        DialogFactory.showDialog(this, "Network Error", getString(R.string.error_no_network), false,  new DialogFactory.DialogButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                System.exit(0);
            }
        }), new DialogFactory.DialogButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                onResume();
            }
        }));
    }

    @Override
    public void showVPNNetworkError() {
        DialogFactory.showDialog(this, "VPN Error", "Please check your VPN Connection and try again", false,  new DialogFactory.DialogButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                System.exit(0);
            }
        }), new DialogFactory.DialogButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                onResume();
            }
        }));
    }
}
