package com.example.intranetsampleapp;

public interface LauncherView {
    void openContainerActivity();
    void showAuthenticationError();
    void showConnectionError();
    void showNetworkError();
    void showVPNNetworkError();
}
