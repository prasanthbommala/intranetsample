package com.example.intranetsampleapp;

/**
 * Configuration file with static network constants
 */
public interface NetworkConstants {

    String WEB_URL = BuildConfig.WEB_URL;
    String WEB_SERVER = WEB_URL + ":8444/dbs-mobile-redesign/api/rest/";

    String WEB_SERVER_OLD = WEB_URL + ":8444/dbs-mobile-server/api/rest/";


    String AZURE_AD_GRAPH_RESOURCE_URL = "https://graph.windows.net";
    String AZURE_AD_LOGIN_URL = "https://login.microsoftonline.com/";
    String CHATBOT_URL = BuildConfig.CHATBOT_URL;

    String WS_RESPONSE_STATUS_SUCCESS = "200 OK";
    String WS_RESPONSE_STATUS_UNAUTHORIZED = "401";


    // Methods
    String WS_GETSTART_USER = "getStartUser";
    String WS_MYBANKAPPS = "getMyBankApps";
    String WS_JOBS = "getJobs";
    String WS_JOBDEPARTMENTS = "getJobDepartments";
    String WS_JOBDETAIL = "getJobDetail";
    String WS_ADDTOFAVOURITES ="addToFavourites";
    String WS_REMOVEFROMFAVOURITES="removeFromFavourites";
    String WS_SURVEYS = "getSurveys";
    String WS_SURVEY_DETAILS = "getSurveyDetail";
    String WS_SURVEY_SUBMIT = "submitSurvey";
    String WS_SURVEY_RESULT = "getSurveyResult";
    String WS_REGISTER_DEVICE = "registerDevice";
    String WS_NOTIFICATION = "getNotifications";
    String WS_NOTIFICATION_DETAIL = "getNotificationDetail";
    String WS_PEOPLE = "getPeople";
    String WS_USER_URL = "getUsersUrl";
    String WS_USER_PROFILE = "getUserProfile";
    String WS_FAVOURITE_PEOPLE = "getFavouritePeopleIds";
    String WS_SHARE_DETAILS = "share";
    String WS_BENEFITS = "getBenefits";
    String WS_DEALS = "getDeals";
    String WS_LEARNINGS = "getMyLearnings";
    String WS_LEARNINGS_DETAILS = "getCourseDetail";
    String WS_CONFERENCE_LIST = "getConferenceList";
    String WS_CONFERENCE_SESSIONS = "getConferenceSessions";
    String WS_CONFERENCE_SPEAKERS = "getConferenceSpeakers";
    String WS_CONFERENCE_ATTENDEES = "getConferenceAttendees";
    String WS_TOP_RATED_EXTERNAL_VIEWS = "getTopRatedExternalViews";
    String WS_TOP_RATED_EXTERNAL_VIEW_DETAIL = "getTopRatedExternalViewDetail";
    String WS_TOP_QUESTIONS = "getTopQuestions";
    String WS_TOP_QUESTIONS_DETAIL = "getTopQuestionDetail";
    String WS_DEAL_DETAILS = "getDealDetail";
    String WS_LIFE_AT_DBS = "getLifeAtDBS";
    String WS_LIFE_AT_DBS_DETAILS = "getLifeAtDBSDetail";
    String WS_INTEREST_GROUPS = "getInterestGroups";
    String WS_INTEREST_GROUP_JOIN = "joinInterestGroup";
    String WS_INTEREST_GROUP_LEAVE = "leaveInterestGroup";
    String WS_CHAT_GROUP_MAX_LIMIT = "getPrivateGroupsCount";
    String WS_CHAT_GROUP_CREATE = "createPrivateGroup";
    String WS_CHAT_GROUP_DELETE = "deletePrivateGroup";
    String WS_CHAT_GROUP_CHECK_GROUP_NAME_EXIST = "checkGroupNameExist";
    String WS_CHAT_GROUP_GET_MEMBERS = "getGroupMembers";
    String WS_INTEREST_GROUPS_PRIVATE = "getClosedGroups";
    String WS_GET_PRIDE = "getPrides";
    String WS_GET_STICKERS = "getStickers";
    String WS_GET_ALL_STICKERS = "getAllStickers";
    String WS_SEND_STICKER = "sendSticker";
    String WS_SEND_PRIDE = "sendPride";
    String WS_RESET_PRIDE_UNREAD_COUNT = "resetPrideUnreadCount";
    String WS_RESET_STICKER_UNREAD_COUNT = "resetStickerUnreadCount";
    String WS_INTEREST_GROUP_DETAILS = "getInterestGroupDetail";
    String WS_INTEREST_GROUP_POST_DETAILS = "getPostDetail";
    String WS_INTEREST_GROUP_CREATE_POST = "createInterestGroupPost";
    String WS_INTEREST_GROUP_DELETE_POST = "deleteInterestGroupPost";
    String WS_INTEREST_GROUP_POST_COMMENT = "sendInterestGroupPostComment";
    String WS_INTEREST_GROUP_POST_LIKE = "sendInterestGroupPostLike";
    String WS_INTEREST_GROUP_POST_UNLIKE = "sendInterestGroupPostUnlike";
    String WS_INTEREST_GROUP_POST_COMMENT_LIKE = "sendPostCommentLike";
    String WS_INTEREST_GROUP_POST_COMMENT_UNLIKE = "sendPostCommentUnlike";
    String WS_INTEREST_GROUP_USERS_JOINED = "getUsersJoinedInterestGroup";
    String WS_INTEREST_GROUP_USERS_LIKED_POST = "getUsersLikedInterestGroupPost";
    String WS_INTEREST_GROUP_USERS_LIKED_PHOTO = "getUsersLikedPhoto";
    String WS_EVENTS_OPEN = "getEvents";
    String WS_EVENTS_PRIVATE = "getClosedEvents";
    String WS_EVENT_DETAILS = "getEventDetail";
    String WS_CONFERENCE_CHAT_GROUPS = "getLC2ClosedGroups";
    String WS_UPDATE_MOOD = "updateUserMood";
    String WS_CLINICS = "getClinics";
    String WS_COURSES = "getCourses";
    String WS_SHUTTLE_BUS_SCHEDULE = "getBusSchedule";
    String WS_CLINICS_DETAILS = "getClinicDetail";
    String WS_CAFETERIA = "getCafeteriaFoodMenu";
    String WS_SUBMIT_FEEDBACK = "sendFeedback";
    String WS_VIEW_FROM_TOP_MENU = "getViewFromTopMenu";
    String WS_CONTACT_INFO = "getCompanyContactInfo";
    String WS_GET_TOOLKIT = "getToolKit";
    String WS_GET_ABOUT_MY_TEAM = "getAboutMyTeam";
    String WS_GET_ABOUT_MY_TEAM_DETAILS = "getAboutMyTeamDetail";
    String WS_GET_ONBOARDING_URL = "getOnBoardingURLs";
    String WS_GET_SUBMIT_SESSION_RATING = "sendSessionRating";
    String WS_SEND_EVENT_RSVP = "sendEventRSVP";
    String WS_GET_RECOGNITION_ITQ_URLS = "getITQURLs";
    String WS_GET_WORK_DAY_URLS = "getHomeLinks";
    String WS_GET_SUBMIT_SPEAKER_RATING = "sendSpeakerRating";
    String WS_GET_SUBMIT_MOJO_FEEDBACK = "submitMojoFeedback";



    String SIT_CRT = "-----BEGIN CERTIFICATE-----\n" +
            "MIIGbDCCBFSgAwIBAgITHAAABVYsI0kY184lrAAAAAAFVjANBgkqhkiG9w0BAQsF\n" +
            "ADB0MRMwEQYKCZImiZPyLGQBGRYDY29tMRMwEQYKCZImiZPyLGQBGRYDZGJzMRUw\n" +
            "EwYKCZImiZPyLGQBGRYFMWJhbmsxFDASBgoJkiaJk/IsZAEZFgRyZWcxMRswGQYD\n" +
            "VQQDExJEQlNCYW5rLUVudC1TdWItQ0EwHhcNMTgwOTA1MDUzNDIwWhcNMjgwOTAy\n" +
            "MDUzNDIwWjBrMQswCQYDVQQGEwJTRzEOMAwGA1UEBxMFSW5mcmExGTAXBgNVBAoT\n" +
            "EERCUyBCYW5rIExpbWl0ZWQxDTALBgNVBAsTBE1EQlMxIjAgBgNVBAMTGXgwMXRt\n" +
            "ZGJzYXBwMWEuc2dwLmRicy5jb20wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK\n" +
            "AoIBAQC3HNZSnSOIvVWS3Gy0yFeeuZ+Xd3y1yzU0926xIHQ0/tpMGNeslHbUXvl6\n" +
            "3WHjs3ae+eSHk9YNCWbqSxEnhXlK1hK5R8SLujd85HcfkRHXajhqHfONTzhbBHvG\n" +
            "i0g4YfxTOGMWYMcqFYPRoqr8LdkM3nqYgfCB2N5kE0r7/r+c19WQG5wWIocEH19V\n" +
            "YdHbJhGMo/7yvnBKLED1y8MnECftYk5VmrdE1n/EW0UMeyM8FmmKcjNhQtyKBrdW\n" +
            "UNJtV6/scPe/zwf7o83mAXa1DGFqrpXMDtMJBP4kz2t4k4BuanNGabt/E1CYHHe8\n" +
            "XuEAQbYnlOzlYo8XlQ2OIM1PeDa9AgMBAAGjggH+MIIB+jAkBgNVHREEHTAbghl4\n" +
            "MDF0bWRic2FwcDFhLnNncC5kYnMuY29tMB0GA1UdDgQWBBSQPpdoEkHCoF3Nyo/r\n" +
            "Ri5ixRIBzTAfBgNVHSMEGDAWgBQZg7IAihLG4MUaAiTwb69wPgR69jBFBgNVHR8E\n" +
            "PjA8MDqgOKA2hjRodHRwOi8vZGJzY3JsLnNncC5kYnMuY29tL2NybC9EQlNCYW5r\n" +
            "LUVudC1TdWItQ0EuY3JsMIHJBggrBgEFBQcBAQSBvDCBuTCBtgYIKwYBBQUHMAKG\n" +
            "galsZGFwOi8vL0NOPURCU0JhbmstRW50LVN1Yi1DQSxDTj1BSUEsQ049UHVibGlj\n" +
            "JTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixE\n" +
            "Qz0xYmFuayxEQz1kYnMsREM9Y29tP2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RD\n" +
            "bGFzcz1jZXJ0aWZpY2F0aW9uQXV0aG9yaXR5MA4GA1UdDwEB/wQEAwIFoDA9Bgkr\n" +
            "BgEEAYI3FQcEMDAuBiYrBgEEAYI3FQiIvBOG3IFhh6GLHYTAxDKEj79kgWWH0qIX\n" +
            "gt+xFAIBZAIBBjATBgNVHSUEDDAKBggrBgEFBQcDATAbBgkrBgEEAYI3FQoEDjAM\n" +
            "MAoGCCsGAQUFBwMBMA0GCSqGSIb3DQEBCwUAA4ICAQB5YUHXeFzZPRlDsjLhXJAM\n" +
            "imHP05maMyKmm5I/sdB1Ak6MRHpvqZ4Ibh8P0QNVUhjs+9gDiYGnVYYHVwqWeKiI\n" +
            "ZKE0LwD7YSmTtRdXj3yy3peVjhpioJD5YMh+Tq6L5WzYNPMAhXL/LhTV+mFG0i0I\n" +
            "Jh96LUNenQm1cCk0QOVsEDZkh19VYnvwW/tOIFE7ViWZUoYPgBc4e/XVFmqANCyQ\n" +
            "z6f78gwXZ56GEZPflRCZsl0bYWhf6VEUvCe/uqojV8PvVuU3RHhB2KkJ8TKwjSFl\n" +
            "uK+3CA7JfnjFZTt0CdQIc5tjvgVktJJEHJt7vO3taaCVGvTDieU2JcyyDzdd/jUU\n" +
            "khjkI1M8bNIN2WvEeq9u7ny76chvfWI9zcseCLSYmIqCRdmm9DCbBhg3hwi1Z7aQ\n" +
            "UwU8nlhTodCGryRwR8UR034rvNfwfQNHZRzvqapb+GRWt3zMyPiQzqkJ24K6Fi+9\n" +
            "RklwsWU0PsccOlWmTi7NmWp0O08NPeSYdkM4eWpFQG0N0TnCCA0aLon0PaDepdQI\n" +
            "+aeh6fl/0crxUX4LXIXruGQoYn66h0GWRvhtclltdPdgUU/upT4AJxDj/m8Csyc/\n" +
            "+W2tEU0dOLprRpgFf55VlFMqhxIoSdUVnVt7mikK/v8B1helpuDcP71T7oDblQdn\n" +
            "tkEs2J3mkZeZNrkbtrszjg==\n" +
            "-----END CERTIFICATE-----\n";


    String UAT_CRT = "-----BEGIN CERTIFICATE-----\n" +
            "MIIGnTCCBIWgAwIBAgITHAAAbwvsHQzeDykbgAAAAABvCzANBgkqhkiG9w0BAQsF\n" +
            "ADB0MRMwEQYKCZImiZPyLGQBGRYDY29tMRMwEQYKCZImiZPyLGQBGRYDZGJzMRUw\n" +
            "EwYKCZImiZPyLGQBGRYFMWJhbmsxFDASBgoJkiaJk/IsZAEZFgRyZWcxMRswGQYD\n" +
            "VQQDExJEQlNCYW5rLUVudC1TdWItQ0EwHhcNMTgxMDMwMDkxNjA0WhcNMjgxMDI3\n" +
            "MDkxNjA0WjBrMQswCQYDVQQGEwJTRzEOMAwGA1UEBxMFSW5mcmExGTAXBgNVBAoT\n" +
            "EERCUyBCYW5rIExpbWl0ZWQxDTALBgNVBAsTBE1EQlMxIjAgBgNVBAMTGXgwMXNt\n" +
            "ZGJzYXBwMWEuc2dwLmRicy5jb20wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK\n" +
            "AoIBAQDC5ip68swwz8CsRsJUFweBozpoxlUCyFlhSrmi2FGjnIzzDpVfqoHlbZwd\n" +
            "5P4rSChQMIl5HL4GvgNqvopRs0uZKGp8QOAWdzH6dgiyZSSor/lcl7EOFdQKRYib\n" +
            "3J1OEjM0MHddqU8P9yMQBA+gLk9UOfPN1YDxx3rTUj176Ab+d1WoyGXTq/hCA1cq\n" +
            "ScE+2wef4fapykLP1jd6L6O75bOz5pyhdXCp4EP5UbTQIWjQGcSFTpJ3xN9r4jhH\n" +
            "0wckFGma5W2fu+p6PpwaN1ZZlapAz+ePrI2MfxMUN343zxruUf1wpNXtMKIF+onZ\n" +
            "0QMCxCi/kV67c9t1YY14zybLQsfbAgMBAAGjggIvMIICKzA/BgNVHREEODA2ghl4\n" +
            "MDFzbWRic2FwcDFhLnNncC5kYnMuY29tghl4MDFzbWRic2FwcDFhLnVhdC5kYnMu\n" +
            "Y29tMB0GA1UdDgQWBBRsOWpPZWbIJbUBv1J6Vy9V+rUmETAfBgNVHSMEGDAWgBQZ\n" +
            "g7IAihLG4MUaAiTwb69wPgR69jBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vZGJz\n" +
            "Y3JsLnNncC5kYnMuY29tL2NybC9EQlNCYW5rLUVudC1TdWItQ0EuY3JsMIHJBggr\n" +
            "BgEFBQcBAQSBvDCBuTCBtgYIKwYBBQUHMAKGgalsZGFwOi8vL0NOPURCU0Jhbmst\n" +
            "RW50LVN1Yi1DQSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049\n" +
            "U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz0xYmFuayxEQz1kYnMsREM9Y29t\n" +
            "P2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9uQXV0\n" +
            "aG9yaXR5MA4GA1UdDwEB/wQEAwIFoDA9BgkrBgEEAYI3FQcEMDAuBiYrBgEEAYI3\n" +
            "FQiIvBOG3IFhh6GLHYTAxDKEj79kgWWH0qIXgt+xFAIBZAIBCDAdBgNVHSUEFjAU\n" +
            "BggrBgEFBQcDAgYIKwYBBQUHAwEwJwYJKwYBBAGCNxUKBBowGDAKBggrBgEFBQcD\n" +
            "AjAKBggrBgEFBQcDATANBgkqhkiG9w0BAQsFAAOCAgEAnGSSDO7LH7+lEFW/7nCt\n" +
            "h+qq0DoSGESk2mIo2pNvz9JdoUDZV7O4RnQLOSwLuTn24BBHvhk4T5WTMdKnlLNY\n" +
            "43MQ+5D97b/i1pVg20QfKIsHlwqKi339o8gEW0IbyPf3wGoz8yyb8M6jr7jsz4q+\n" +
            "JD/2J45CVkdjsogGtOdegGq3b8fp/1f3MKekS9SY28yZn/V5V39sNcNBj6XSDdqo\n" +
            "uEIe4cbN7btvI99teAeNvr4BjgDbOhwgp7Id0u6pRhlOJfeHmDhZmQAbh7F/LYr/\n" +
            "v+8w34bIFRTQA673TcIM9hYtDgdeBCIsaJpr0Rr6Uij5C2FC7Apvu2tfc/o3k2bg\n" +
            "jlC+r5oCWDBBT3G4c1Q2WjYAfybZb3l15f5C5hafiEMt1YlkeSmBjGGpkJuc3B1W\n" +
            "7fKBgSTSp8CvL1TKUgEFoZ+I6iejLZQLH6zyUMKJ67wjyd4dnYG+kM7Zl9pCBNnK\n" +
            "L4YjgVHWPuEes7jWJxLKueOt28b2t7p9SQ2WoLxMVYjYi14Pf7ANIVo/imITUfFU\n" +
            "G8Fgmj3lW7kd/UD8/VerUaqVWGui+WKIrYM1x84NNIKkXonSEBe2bZQ8gqECoOTl\n" +
            "nH+mFP9UG8hDBtx5MJWDE3popXxAgzp1+VzWTHwZmQ8FXmGernBwPy5dLUIaiaK+\n" +
            "tyWJ9nHqdPFDlY0Oa+rMisY=\n" +
            "-----END CERTIFICATE-----\n";


    String PRD_CRT = "-----BEGIN CERTIFICATE-----\n" +
            "MIIGbDCCBFSgAwIBAgITHAAABVhrR3/eeUqeoAAAAAAFWDANBgkqhkiG9w0BAQsF\n" +
            "ADB0MRMwEQYKCZImiZPyLGQBGRYDY29tMRMwEQYKCZImiZPyLGQBGRYDZGJzMRUw\n" +
            "EwYKCZImiZPyLGQBGRYFMWJhbmsxFDASBgoJkiaJk/IsZAEZFgRyZWcxMRswGQYD\n" +
            "VQQDExJEQlNCYW5rLUVudC1TdWItQ0EwHhcNMTgwOTA1MDUzNDIxWhcNMjgwOTAy\n" +
            "MDUzNDIxWjBrMQswCQYDVQQGEwJTRzEOMAwGA1UEBxMFSW5mcmExGTAXBgNVBAoT\n" +
            "EERCUyBCYW5rIExpbWl0ZWQxDTALBgNVBAsTBE1EQlMxIjAgBgNVBAMTGXgwMWdt\n" +
            "ZGJzYXBwMWEuc2dwLmRicy5jb20wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK\n" +
            "AoIBAQDp5A22X+pwnRHHh1A3/akuwW92WAuX9SzZLfC5hk94CMGF7Zajd84wFcm6\n" +
            "OrBXHhIaVdIFiboSdiNS/M4zADpSudfCLZg0vhulb3asqN1tgkt4yZ3/NUkD1egP\n" +
            "AF/bXhfY5LGA0vRdGUFcsiqVHUe98rGtzewwyJXuEed4gD2wPT8b4IMkDtWRTmdE\n" +
            "Zie2OZtQVU6Vy3f/frYJdJ70RCMELddgVqZOsORY/DXSKKQyjXhFBLi9ukjeU5W9\n" +
            "dRNMIJ2k9XmZlR/pxjKzJkR5qHbr+HnIgWdXVTqewyCWPV9RJn4qnxkBwa3133e9\n" +
            "Vs7ZkrMyBUwqJUfj2N2/MCwmTlnFAgMBAAGjggH+MIIB+jAkBgNVHREEHTAbghl4\n" +
            "MDFnbWRic2FwcDFhLnNncC5kYnMuY29tMB0GA1UdDgQWBBTzUtVhqyx0dugBpiPL\n" +
            "D7D1E/a/JzAfBgNVHSMEGDAWgBQZg7IAihLG4MUaAiTwb69wPgR69jBFBgNVHR8E\n" +
            "PjA8MDqgOKA2hjRodHRwOi8vZGJzY3JsLnNncC5kYnMuY29tL2NybC9EQlNCYW5r\n" +
            "LUVudC1TdWItQ0EuY3JsMIHJBggrBgEFBQcBAQSBvDCBuTCBtgYIKwYBBQUHMAKG\n" +
            "galsZGFwOi8vL0NOPURCU0JhbmstRW50LVN1Yi1DQSxDTj1BSUEsQ049UHVibGlj\n" +
            "JTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixE\n" +
            "Qz0xYmFuayxEQz1kYnMsREM9Y29tP2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RD\n" +
            "bGFzcz1jZXJ0aWZpY2F0aW9uQXV0aG9yaXR5MA4GA1UdDwEB/wQEAwIFoDA9Bgkr\n" +
            "BgEEAYI3FQcEMDAuBiYrBgEEAYI3FQiIvBOG3IFhh6GLHYTAxDKEj79kgWWH0qIX\n" +
            "gt+xFAIBZAIBBjATBgNVHSUEDDAKBggrBgEFBQcDATAbBgkrBgEEAYI3FQoEDjAM\n" +
            "MAoGCCsGAQUFBwMBMA0GCSqGSIb3DQEBCwUAA4ICAQB2bhGhLUx77iz6px2JrCmU\n" +
            "0MawmsN1MjDtikryEUMWaa6IvuLaxWjd0+9rwQ7Fsjz9BeI4Kbi0EgL9IS4Vdm/C\n" +
            "THEuP5AMhi1rtxF5oXLdrfOWE8jsN71pfNnLBaZ+Fh/pqak/XNlcQ3LE3U/eSnPt\n" +
            "fW/UBs7C4cOyIeKeWLfYVFost9p2z/yhvIqLNYZm8UnwyYl1gVutgkKmFl1qBxin\n" +
            "KepH4E8oMgLPEHHANv2q+nvSqqjDAtVCUi2zx6auaU8/zsZ1voTDY3xcbkoUWhq3\n" +
            "mRMeDCeofI5/5MCZZSkvABfUqAIsHkbLYqq8LtD73smewQwYwbcXWp4KmAOH5cad\n" +
            "M/2lq5Q2vjwoR+aGIWEm6YPRph6Ovnim1qI2dX20ytIzIsYAQ4ywVQtP9KRMXqx6\n" +
            "60EjS7rLFXVjCt/dsFIOO27PKw+91ZU03ZG2XFl2vdiMzyGIQocLI9j8qW5FCqsU\n" +
            "pN+n1WoYJR2K8J3Hv4lo1wH9bEUY0AJoUI0ilxFDrNDdDS6wBvegOrQgx35bZXTa\n" +
            "9Vzcdy9idc7W1llFXXKK9VPQ8KJ83JBonlfxvdZytQX34l6sH7sBQ7/PnJRG2NLz\n" +
            "baaF9cJif5tkBNcDc8kUq8qzCY1SPdsmezbCQRKuFWrukf0k03w0KBMWrQGb8tlg\n" +
            "y1FskUbbw3AtwbtV70MsjA==\n" +
            "-----END CERTIFICATE-----\n";
}
