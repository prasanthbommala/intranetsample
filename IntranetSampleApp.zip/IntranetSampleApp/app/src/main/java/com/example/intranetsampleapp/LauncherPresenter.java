package com.example.intranetsampleapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.microsoft.aad.adal.ADALError;
import com.microsoft.aad.adal.AuthenticationCallback;
import com.microsoft.aad.adal.AuthenticationException;
import com.microsoft.aad.adal.AuthenticationResult;

import java.util.Timer;
import java.util.TimerTask;

import static com.example.intranetsampleapp.LauncherActivity.azureId;

public class LauncherPresenter {

    private LauncherView loginView;
    private LauncherInteractor loginInteractor;
    ProgressDialog  progressDialog;
    private Activity mActivity;
    private  Context mContext ;
    private TokenHelper mTokenHelper;
    private String mAzureId;
    private SharedPreferences sharedPref;


    LauncherPresenter(LauncherView loginView, LauncherInteractor loginInteractor) {
        this.loginView = loginView;
        this.loginInteractor = loginInteractor;

    }
    public void initializeAccessToken(final Activity activity,SharedPreferences sharedpreferences) {
        mTokenHelper = TokenHelper.getInstance(activity);
        sharedPref = sharedpreferences;

        Toast.makeText(activity, "initializeAccessToken ", Toast.LENGTH_SHORT).show();
        Log.d("TAG","initializeAccessToken");
        if(!NetworkUtil.isNetworkConnected(activity)){
            loginView.showNetworkError();
            return;
        }
        if(!NetworkUtil.isVPNenabled(activity)){
            progressDialog = new ProgressDialog(activity);
            showProgressDialogWithTitle();
            final Handler handler = new Handler();
            final Timer t = new Timer();
            t.schedule(new TimerTask() {
                public void run() {
                    handler.post(new Runnable() {
                        public void run() {
                            if(!NetworkUtil.isVPNenabled(activity)){

                                Toast.makeText(activity, "checking vpn connection", Toast.LENGTH_SHORT).show();
                                loginView.showVPNNetworkError();
                                hideProgressDialogWithTitle();
                                t.cancel();
                                return ;
                            } else {
                                Toast.makeText(activity, "Timer cancelled", Toast.LENGTH_SHORT).show();
                                t.cancel();
                                hideProgressDialogWithTitle();
                                afterCompletion(activity);
                                Toast.makeText(activity, "After 5 sec executed", Toast.LENGTH_SHORT).show();

                            }
                            //DO SOME ACTIONS HERE , THIS ACTIONS WILL WILL EXECUTE AFTER 5 SECONDS...
                        }
                    });
                }
            }, 1000);
        } else {
            Toast.makeText(activity, "at initializeAccessToken", Toast.LENGTH_SHORT).show();
            Log.d("TAG"," at initializeAccessToken");
            afterCompletion(activity);
        }
    }

    private void afterCompletion(Activity activity){

        Toast.makeText(activity, "at afterCompletion", Toast.LENGTH_SHORT).show();
        Log.d("TAG"," at afterCompletion");
        mActivity = activity;
        if (sharedPref.contains(azureId)) {
            String azureADUserId = sharedPref.getString(azureId,"");
            mTokenHelper.callAcquireTokenSilentAsyc(azureADUserId, acquireTokenSilentCallback);
        } else{
            mTokenHelper.callAcquireToken(activity, acquireTokenCallback);
        }


    }

    private AuthenticationCallback<AuthenticationResult> acquireTokenCallback = new AuthenticationCallback<AuthenticationResult>() {
        @Override
        public void onSuccess(AuthenticationResult authResult) {
            Toast.makeText(mActivity, "at after Completion success call back", Toast.LENGTH_SHORT).show();
            if (authResult.getUserInfo() != null) {
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString(azureId, authResult.getUserInfo().getUserId());
                editor.commit();
            }
            onTokenAcquired(authResult);
        }

        @Override
        public void onError(Exception exc) {
            exc.printStackTrace();
            failedToAcquireToken(exc);
        }
    };

    private AuthenticationCallback<AuthenticationResult> acquireTokenSilentCallback = new AuthenticationCallback<AuthenticationResult>() {
        @Override
        public void onSuccess(AuthenticationResult result) {
            Toast.makeText(mContext, "success silent", Toast.LENGTH_SHORT).show();
            onTokenAcquired(result);
        }

        @Override
        public void onError(Exception exc) {
            Toast.makeText(mContext, "failure silent", Toast.LENGTH_SHORT).show();
            exc.printStackTrace();
            failedToAcquireToken(exc);
        }
    };

    private void onTokenAcquired(AuthenticationResult authenticationResult) {
        callGetStart();
    }
    private void callGetStart(){
            loginView.openContainerActivity();
    }

    private void failedToAcquireToken(Exception ex) {
        if(ex instanceof AuthenticationException){
            AuthenticationException e = (AuthenticationException) ex;

            if(e.getCode() == ADALError.AUTH_REFRESH_FAILED_PROMPT_NOT_ALLOWED){
                mTokenHelper.callAcquireToken(mActivity, acquireTokenCallback);
            }
        }else{
            if (loginView != null) loginView.showAuthenticationError();
        }

    }
    private void showProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //Without this user can hide loader by tapping outside screen
        progressDialog.setCancelable(false);

        progressDialog.setMessage("Checking VPN Connection");
        progressDialog.show();
    }

    // Method to hide/ dismiss Progress bar
    private void hideProgressDialogWithTitle() {
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.dismiss();
    }
}
