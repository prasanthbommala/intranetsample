package com.example.intranetsampleapp;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;


public class NetworkUtil {
    public static  ConnectivityManager cm;

    /**
     * Returns true if the Throwable is an instance of RetrofitError with an
     * http status code equals to the given one.
     */

    public static boolean isNetworkConnected(Context context) {
        cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }

    public static boolean isVPNenabled(Context context){
        boolean vpnInUse=false;
        if(Build.VERSION.SDK_INT >= 23) {
            Network activeNetwork = cm.getActiveNetwork();
            NetworkCapabilities caps = cm.getNetworkCapabilities(activeNetwork);
            vpnInUse = caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
        } else if(Build.VERSION.SDK_INT >= 21 && Build.VERSION.SDK_INT < 23){
            vpnInUse = true;
        }
        return vpnInUse;
    }

}