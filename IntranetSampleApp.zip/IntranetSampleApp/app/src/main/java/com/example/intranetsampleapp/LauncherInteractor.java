package com.example.intranetsampleapp;

public class LauncherInteractor {
}
